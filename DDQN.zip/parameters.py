import numpy as np

def initialize_parameters(num_cycles=7, num_stations=5, max_gen=300):
    # 定义并初始化参数
    num_cycles = 7  # 假设7个周期
    num_stations = 5  # 假设5个工作台
    max_inventory = 10  # 最大库存量
    # 每个工作站的初始库存
    initial_inventory_value = 5  # 每个工作站的初始库存
    # 动态生成初始库存列表
    initial_inventory = [initial_inventory_value] * num_stations
    max_inventory = 10  # 每个工作站的最大库存
    max_vehicle_loads = [70, 90]  # 两种车型的最大载重（车型1: 70kg，车型2: 90kg）
    # 初始化车辆自重（假设有2种不同类型的车辆）
    vehicle_weights = [30, 50]  # 车型自重（假设2种类型的车）
    max_vehicle_counts = [10, 5]  # 两种车型的最大箱数（车型1: 10箱，车型2: 5箱）
    warehouse_to_stations_distance = 10  # 仓库到每个工作站的距离
    stations_distance = 1  # 每个工作站之间的距离
    # 动态生成距离字典
    distances = {
        'warehouse': [warehouse_to_stations_distance] * num_stations,  # 仓库到每个工作站的距离
        'stations': np.full((num_stations, num_stations), stations_distance)  # 工作站之间的距离矩阵
    }
    # 对角线设置为0（站点到自身的距离为0）
    np.fill_diagonal(distances['stations'], 0)
    # 每个工作站的物料消耗量以及其对应的每箱物料重量
    demand = np.random.randint(1, 6, size=(num_stations, 1))  # 每个 station 的消耗（1到5之间的整数）
    weights = np.random.choice([5, 20], size=(num_stations, 1))  # 每个 station 的重量（5或20）

    # 使用 np.tile 扩展 demand 和 weights 到 num_cycles 周期
    demand = np.tile(demand, (1, num_cycles))  # 扩展为 (num_stations, num_cycles)
    weights = np.tile(weights, (1, num_cycles))  # 扩展为 (num_stations, num_cycles)
    f_num = 2  # 目标个数
    NP = 100  # 种群大小



    return num_cycles, num_stations, max_inventory, distances, weights, f_num, NP, max_gen, vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts



