import numpy as np
import math


# from numba import jit

# @jit(nopython=True) # jit，numba装饰器中的一种
def ES(pop):
    # 提取帕累托前沿解
    PF = []
    for i in range(len(pop)):
        if pop[i].paretorank == 1 and pop[i].f not in PF:
            PF.append(pop[i].f)

    # 归一化
    PF = np.array(PF)
    PF[:, 0] = (PF[:, 0] - min(PF[:, 0])) / (max(PF[:, 0]) - min(PF[:, 0]) + 1)
    PF[:, 1] = (PF[:, 1] - min(PF[:, 1])) / (max(PF[:, 1]) - min(PF[:, 1]) + 1)
    # PF[:,0] = (PF[:,0]) / (max(PF[:,0])- min(PF[:,0]))
    # PF[:,1] = (PF[:,1]) / (max(PF[:,1])- min(PF[:,1]))
    # print(PF)
    # 计算Di
    m = len(PF)
    if m == 1: return 0  # 当前沿只有一个解
    mind = np.zeros(m)
    Di = np.zeros(m)
    for i in range(m):
        for j in range(m):
            if i != j:
                mind[j] = math.sqrt(np.square(np.array(PF[i]) - np.array(PF[j])).sum())
        Di[i] = min(mind)
    D = Di.sum() / m
    # 计算ES
    mind = np.zeros(m)
    Di = np.zeros(m)
    for i in range(m):
        for j in range(m):
            if i != j:
                mind[j] = math.sqrt(np.square(np.array(PF[i]) - np.array(PF[j])).sum())
        Di[i] = min(mind) - D
    ES = math.sqrt(np.square(Di).sum() / m) / D
    # print(PF,Di) #出现nan的原因，D变成了0,Di全是0
    return ES


# @jit(nopython=True) # jit，numba装饰器中的一种
def HV(pop):
    # 提取帕累托前沿解
    PF = []
    for i in range(len(pop)):
        if pop[i].paretorank == 1 and pop[i].f not in PF:
            PF.append(pop[i].f)
    # 计算HV
    HV = 0
    PF = np.array(PF)
    for i in range(len(PF[0])):
        PF[:, i] = (PF[:, i] - np.min(PF[:, i])) / (np.max(PF[:, i]) - np.min(PF[:, i]) + 1)
    index_sort = np.argsort(PF[:, 0])
    # print(PF)
    PF = PF[index_sort]
    PF = PF[:: - 1]
    # print(PF)
    ref = [1.1, 1.1]  # 1.1, 1.1
    for i in range(len(PF)):
        if i == 0:
            HV += abs((ref[0] - PF[i, 0]) * (ref[1] - PF[i, 1]))
        else:
            HV += abs((PF[i - 1, 0] - PF[i, 0]) * (ref[1] - PF[i, 1]))
    return HV


def init_HV(pop, fmax):
    # 提取帕累托前沿解
    PF = []
    for i in range(len(pop)):
        if pop[i].paretorank == 1 and pop[i].f not in PF:
            PF.append(pop[i].f)
    HV = 0
    PF = np.array(PF)
    index_sort = np.argsort(PF[:, 0])
    # print(PF)
    PF = PF[index_sort]
    PF = PF[:: - 1]
    # print(PF)
    ref = fmax
    for i in range(len(PF)):
        if i == 0:
            HV += abs((ref[0] - PF[i, 0]) * (ref[1] - PF[i, 1]))
        else:
            HV += abs((PF[i - 1, 0] - PF[i, 0]) * (ref[1] - PF[i, 1]))
    return HV