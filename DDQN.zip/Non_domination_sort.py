#N种群大小
#chromo种群
#f_num目标个数
#x_num决策变量个数
# from numba import jit

#@jit(nopython=True) # jit，numba装饰器中的一种
def non_domination_sort(NP,pop,f_num):
    #初始化pareto等级为1
    pareto_rank=1
    F={}#初始化一个字典
    F[pareto_rank]=[]#pareto等级为pareto_rank的集合
    pn={}
    ps={}
    for i in range(NP):
        #计算出种群中每个个体p的被支配个数n和该个体支配的解的集合s
        pn[i]=0#被支配个体数目n
        ps[i]=[]#支配解的集合s
        for j in range(NP):
            less=0#y'的目标函数值小于个体的目标函数值数目
            equal=0#y'的目标函数值等于个体的目标函数值数目
            greater=0#y'的目标函数值大于个体的目标函数值数目
            for k in range(f_num):
                if (pop[i].f[k]<pop[j].f[k]):
                    less=less+1
                elif (pop[i].f[k]==pop[j].f[k]):
                    equal=equal+1
                else:
                    greater=greater+1
            if (less==0 and equal!=f_num):
                pn[i]=pn[i]+1
            elif (greater==0 and equal!=f_num):
                ps[i].append(j)
        if (pn[i]==0):
            pop[i].paretorank=1#储存个体的等级信息
            F[pareto_rank].append(i)
    #求pareto等级为pareto_rank+1的个体
    while (len(F[pareto_rank])!=0):
        temp=[]
        for i in range(len(F[pareto_rank])):
            if (len(ps[F[pareto_rank][i]])!=0):
                for j in range(len(ps[F[pareto_rank][i]])):
                    pn[ps[F[pareto_rank][i]][j]]=pn[ps[F[pareto_rank][i]][j]]-1#nl=nl-1
                    if pn[ps[F[pareto_rank][i]][j]]==0:
                        pop[ps[F[pareto_rank][i]][j]].paretorank=pareto_rank+1#储存个体的等级信息
                        temp.append(ps[F[pareto_rank][i]][j])
        pareto_rank=pareto_rank+1
        F[pareto_rank]=temp
    return F,pop