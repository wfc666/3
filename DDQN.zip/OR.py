def OR(pop):
    OR = []
    for i in range(len(pop)):
        if pop[i].paretorank == 1:
            OR.append(pop[i].f[0] * pop[i].f[1])
    return sum(OR) / len(OR)