import numpy as np
import time
import random

from operators import MO1, MO2, MO3, CO1, CO2, CO3
# LS1, LS2
rate_LS1 = 0.4  # LS1局部优化比例
rate_LS2 = 0.6  # LS2局部优化比例


class Env():
    def __init__(self):
        self.action_space = ['MO1', 'MO2', 'MO3', 'CO1', 'CO2', 'CO3', 'LS1', 'LS2']
        self.n_actions = len(self.action_space)
        self.n_features = 2
        # self.title('maze')
        # self.geometry('{0}x{1}'.format(MAZE_H * UNIT, MAZE_H * UNIT))
        # self._build_maze()

    def update_pop(self, pop, action, S, T, station_capacity, I0, demand, RP, max_station_capacity_A,
                   max_station_capacity_B, material_type):
        action = self.action_space[action]
        pop_offspring = []
        if action == 'MO1':
            for i in range(len(pop)):
                pop_offspring.append(MO1(pop[i].individual, S, T, station_capacity))
        elif action == 'MO2':
            for i in range(len(pop)):
                pop_offspring.append(MO2(pop[i].individual, S, T, station_capacity))
        elif action == 'MO3':
            for i in range(len(pop)):
                pop_offspring.append(MO2(pop[i].individual, S, T, station_capacity))
        elif action == 'CO1':
            for i in range(len(pop)):
                individual1 = pop[i].individual
                individual2 = pop[random.randint(0, len(pop) - 1)].individual
                pop_offspring.append(CO1(individual1, individual2, S, T, station_capacity))
        elif action == 'CO2':
            for i in range(len(pop)):
                individual1 = pop[i].individual
                individual2 = pop[random.randint(0, len(pop) - 1)].individual
                pop_offspring.append(CO2(individual1, individual2, S, T, station_capacity))
        elif action == 'CO3':
            for i in range(len(pop)):
                pop_offspring.append(CO3(pop[i].individual, S, T, station_capacity))
        # elif action == 'LS1':
        #     for i in range(len(pop)):
        #         if random.random() < rate_LS1:
        #             pop_offspring.append(
        #                 LS1(pop[i].individual, S, T, station_capacity, I0, demand, RP, max_station_capacity_A,
        #                     max_station_capacity_B, material_type))
        # elif action == 'LS2':
        #     for i in range(len(pop)):
        #         if random.random() < rate_LS2:
        #             pop_offspring.append(
        #                 LS2(pop[i].individual, S, T, station_capacity, I0, demand, RP, max_station_capacity_A,
        #                     max_station_capacity_B, material_type))

        return pop_offspring

    def get_reward(self, OR_value, new_OR, ES_value, HV_value, ES, HV):
        if OR_value > new_OR:
            f_OR = 1
        elif OR_value < new_OR:
            f_OR = 0
        else:
            f_OR = 0
        if ES < ES_value and HV > HV_value:
            return 2 + f_OR
        elif ES > ES_value and HV < HV_value:
            return -2 + f_OR
        elif (ES > ES_value and HV > HV_value):
            if HV / HV_value >= ES / ES_value:
                return 1 + f_OR
            else:
                return -1 + f_OR
        elif (ES < ES_value and HV < HV_value):
            if ES_value / ES >= HV_value / HV:
                return 1 + f_OR
            else:
                return -1 + f_OR
        else:
            return 0 + f_OR
