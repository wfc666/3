import random
from initialize import Individual

import numpy as np
from numba import jit


Pm = 0.2
Pc = 0.9
#Cn = round(T * S / 10) #Crossover_number
rate_LS1 = 0.3 #LS1局部优化比例
rate_LS2 = 0.6 #LS2局部优化比例
vmin = 0
vmax = 1
vmid = 0.5

# @jit(nopython=True) # jit，numba装饰器中的一种
def MO1(individual, S, T, station_capacity):
    for i in range(S * T):
        if random.random() < Pm:
            individual[i] = random.random()
        if random.random() < Pm:
            individual[S * T + i] = random.randint(0, station_capacity[i % S])
    return Individual(individual, T, S, station_capacity)

# @jit(nopython=True) # jit，numba装饰器中的一种
def MO2(individual, S, T, station_capacity):
    for i in range(S * T):
        if random.random() < Pm:
            rd = np.random.normal(loc=0.5, scale=0.4)
            if rd < vmin:
                individual[i] = vmin
            elif rd > vmax:
                individual[i] = vmax
            else:
                individual[i] = rd
            rd = np.random.normal(loc=station_capacity[i % S]-2, scale=station_capacity[i % S]+1)
            if rd < 0:
                individual[S * T + i] = 0
            elif rd > station_capacity[i % S]:
                individual[S * T + i] = station_capacity[i % S]
            else:
                individual[S * T + i] = round(rd)
    return Individual(individual, T, S, station_capacity)

# @jit(nopython=True) # jit，numba装饰器中的一种
def MO3(individual, S, T, station_capacity):
    opposition_point1 = np.random.random(S * T) * individual[:S * T]
    opposition_point2 = np.random.random(S * T) * (vmax + vmin)
    opposition_point = np.concatenate((opposition_point1, opposition_point2))
    return Individual(opposition_point, T, S, station_capacity)

# @jit(nopython=True) # jit，numba装饰器中的一种
def CO1(individual1, individual2, S, T, station_capacity):
    new_individual = []
    if random.random() < Pc:
        point1 = random.randint(1, S * T * 2 - 1)
        point2 = random.randint(1, S * T * 2 - 1)
        while point1 == point2:
            point2 = random.randint(1, S * T * 2 - 1)
        new_individual = np.concatenate((individual1[: point1], individual2[point1: point2], individual1[point2:]))
    individual = new_individual if new_individual == [] else individual1
    return Individual(individual, T, S, station_capacity)

# @jit(nopython=True) # jit，numba装饰器中的一种
def CO2(individual1, individual2, S, T, station_capacity):
    for i in range(S * T * 2):
        if random.random() < Pc / 10:
            individual1[i] = individual2[i]
    return Individual(individual1, T, S, station_capacity)

# @jit(nopython=True) # jit，numba装饰器中的一种
def CO3(individual, S, T, station_capacity):
    Cn = round(T * S / 10)
    for i in range(Cn):
        point1 = random.randint(0, S * T - 1)
        point2 = random.randint(0, S * T - 1)
        while point1 == point2:
            point2 = random.randint(0, S * T - 1)
        individual[point1], individual[point2] = individual[point2], individual[point1]
        individual[S * T + point1], individual[S * T + point2] = individual[S * T + point2], individual[S * T + point1]
    return Individual(individual, T, S, station_capacity)

# @jit(nopython=True) # jit，numba装饰器中的一种