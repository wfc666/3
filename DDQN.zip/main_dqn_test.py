import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import math
import time
import sys
from scipy.io import savemat

from parameters import initialize_parameters
from initialize import Individual
from obj import objective
from Non_domination_sort import non_domination_sort
from Crowding import crowding_distance_sort
from performance import ES, HV, init_HV
from environment import Env
from q_learning import QLearningAgent
from dqn import DeepQNetwork
from dqn_env import Env
from Elitism import elitism
from OR import OR

tart = time.time()  # 开始计时
action_set = []

minf1 = []
minf2 = []

if __name__ == '__main__':

    # %% 迭代循环episode
    env = Env()
    agent = DeepQNetwork(env.n_actions, env.n_features,
                         learning_rate=0.01,
                         reward_decay=0.9,
                         e_greedy=0.8,
                         replace_target_iter=150,
                         memory_size=300,
                         batch_size=4,
                         output_graph=False,
                         e_greedy_increment=None,
                         train_or_test='test'
                         )
    for episode in range(1):
        num_stations, num_cycles = 50, 50
        max_gen = 300
        # %%导入参数
        (num_cycles, num_stations, max_inventory, distances, weights, f_num, NP, max_gen, vehicle_weights,
         demand, initial_inventory, max_vehicle_loads, max_vehicle_counts) = initialize_parameters(max_gen=300)

        # %%初始化种群
        pop = []
        for i in range(NP):
            pop.append(Individual([], num_cycles, num_stations))

        # %%计算目标值和最大值
        for i in range(NP):
            pop[i].f = objective(pop[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                                 vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,
                                 f_num)

        # %%计算帕累托等级
        F, pop = non_domination_sort(NP, pop, f_num)

        # %% 计算拥挤度距离
        pop = crowding_distance_sort(F, pop, f_num)

        # %% 计算最小目标值
        x, y = [], []
        for i in range(len(pop)):
            if pop[i].paretorank == 1:
                x.append(pop[i].f[0])
                y.append(pop[i].f[1])
        minf1.append(min(x))
        minf2.append(min(y))

        # %% 计算ES 和 HV
        ES_value = ES(pop)
        HV_value = HV(pop)

        # %% 计算OR
        OR_value = OR(pop)

        # %% 迭代循环max_gen
        for gen in range(max_gen):
            # 更新epsilon
            agent.update_epsilon(gen, max_gen)
            # 产生动作
            action = agent.choose_action([ES_value, HV_value])
            action_set.append(action)
            print(action_set[-1])

            # 可视化
            # net_matrix = np.array([[0 for _ in range(120)] for _ in range(120)])
            # for i in range(120):
            #     for j in range(120):
            #         a = agent.choose_action([0.01*i,0.01*j])
            #         net_matrix[i][j]=a
            # X = np.arange(0, 1.2, 0.01)
            # Y = np.arange(0, 1.2, 0.01)
            # X, Y = np.meshgrid(X, Y)    # x-y 平面的网格
            # R = net_matrix
            # fig = plt.figure(dpi=300)
            # ax = Axes3D(fig)
            # ax.set_xlabel('ES')
            # ax.set_ylabel('HV')
            # ax.set_zlabel('Value function')
            # ax.set_zlim((0,7.3))
            # # ax.view_init(elev=90)#,azim=90
            # ax.plot_surface(X, Y, R, rstride=1, cstride=1, cmap=plt.get_cmap('rainbow'))
            # sys.exit(0)

            # print(action)

            # 根据产生的动作产生新一代种群
            pop_offspring = env.update_pop(pop, action, num_cycles, num_stations, max_inventory, distances, weights,
                                           vehicle_weights, demand, initial_inventory, max_vehicle_loads,
                                           max_vehicle_counts)

            # 计算目标值
            for i in range(len(pop_offspring)):
                pop_offspring[i].f = objective(pop_offspring[i].individual, num_cycles, num_stations, max_inventory,
                                               distances, weights,
                                               vehicle_weights, demand, initial_inventory, max_vehicle_loads,
                                               max_vehicle_counts, f_num)

            # 合并种群
            pop_comb = pop + pop_offspring
            # 计算帕累托
            F, pop_comb = non_domination_sort(len(pop_comb), pop_comb, f_num)
            # 计算拥挤度距离
            pop_comb = crowding_distance_sort(F, pop_comb, f_num)
            # 选择前NP个个体
            pop = elitism(NP, pop_comb, f_num)
            # 计算ES 和 HV
            new_ES = ES(pop)
            new_HV = HV(pop)
            # 计算OR
            new_OR = OR(pop)
            # 计算回报
            reward = env.get_reward(OR_value, new_OR, ES_value, HV_value, new_ES, new_HV)
            # 储存经验
            agent.store_transition([ES_value, HV_value], action, reward, [new_ES, new_HV])
            # 更新Q表
            agent.learn()

            # 更新
            ES_value = new_ES
            HV_value = new_HV
            OR_value = new_OR
            print(episode, gen, ES_value, HV_value, OR_value)

            # 作图
            x, y = [], []
            for i in range(len(pop)):
                if pop[i].paretorank == 1:
                    x.append(pop[i].f[0])
                    y.append(pop[i].f[1])
            minf1.append(min(x))
            minf2.append(min(y))

            if gen % 10 == 0:
                plt.scatter(x, y, marker='o', color='red', s=40)
                plt.xlabel('f1')
                plt.ylabel('f2')
                plt.show()

            stop = time.time()
            print(stop - start)
            # if stop - start > 200:
            #     break
    # %%

    plt.figure(dpi=300)
    plt.scatter(list(range(max_gen)), action_set, s=10)
    plt.yticks([0, 1, 2, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 6, 7, 8])
    plt.show()
    # 存储最小目标值和pf
    # savemat('./对比实验/对比1/dqn_f1_5.mat', {'f1': minf1})
    # savemat('./对比实验/对比1/dqn_f2_5.mat', {'f2': minf2})
    x = np.array([x]).T
    y = np.array([y]).T
    xy = np.concatenate((x, y), axis=1)
    savemat('./节拍时间/pf_60.mat', {'pf': xy})

    end = time.time()
    print("循环时间：%2f秒" % (end - start))
    import winsound

    winsound.Beep(200, 1000)
    print(minf1[-1], minf2[-1])