import numpy as np
import random
import time
class Individual():  # 这段定义了一个 Individual类, 上界、下界
    vmin = 0
    vmax = 10
    # vmid = 0.5


    def __init__(self, individual, num_cycles, num_stations):
        self.paretorank = 0  # Pareto 前沿中的等级
        self.nnd = 0  # 最近邻的距离
        self.individual = individual
        self.f = np.zeros(2)
        # # 初始化库存和补货数量
        # inventory = np.zeros((num_stations, num_cycles))
        # inventory[:, 0] = initial_inventory

        if self.individual == []:
            self.individual = np.random.randint(Individual.vmin, Individual.vmax + 1, (num_stations, num_cycles))


if __name__ == '__main__':
    start = time.time()  # 开始计时
    individual = []
    a = Individual(individual, 10, 10)
    print(a.individual)
    # print(a[:100])
    end = time.time()
    print("运行时间：%2f秒" % (end - start))