import time
import os
os.environ['NUMBA_DISABLE_JIT'] = '1'

#运行多个文件
start1 = time.time()
exec(open("main_ql_test.py", encoding = 'utf-8').read())
end1 = time.time()
exec(open("main_dqn_test.py", encoding = 'utf-8').read())
end2 = time.time()
exec(open("main_HH_RG.py", encoding = 'utf-8').read())
end3 = time.time()

print(end1-start1, end2-start1, end3-start1)

import winsound
winsound.Beep(200,1000)