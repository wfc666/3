import numpy as np
from parameters import initialize_parameters
from initialize import *


# 分配车辆,解码
def decode(num_cycles, num_stations, individual,initial_inventory, demand, max_inventory, weights, max_vehicle_loads, max_vehicle_counts):
    # 库存计算
    # 初始化库存和补货层
    inventory = np.zeros((num_stations, num_cycles))
    inventory[:, 0] = initial_inventory
    for t in range(num_cycles):
        for m in range(num_stations):
            if t > 0:
                inventory[m, t] = inventory[m, t - 1] + individual[m, t] - demand[m, t]

    # 分配车辆
    vehicle_allocations = []
    # 工作站补货任务创建
    for t in range(num_cycles):
        period_allocation = []
        remaining_demand = list(individual[:, t])
        vehicles_for_period = []
        # 检查是否仍有未满足的需求 没分配完则需要分配车辆
        while any(d > 0 for d in remaining_demand):
            vehicle_assignment = []  # 如果所有工作站的需求都满足（即 remaining_demand 中所有值均为 0），任务分配结束
            # 遍历每种车型，尝试为当前车型分配工作站任务
            for model_idx in range(len(max_vehicle_loads)):
                vehicle_capacity = max_vehicle_loads[model_idx]  # 每种车型具有最大载重量
                vehicle_boxes = 0  # 当前车型已分配的物料箱数量
                current_vehicle_type = f"车型{model_idx + 1}"  # 当前车型标识
                # 遍历每个工作站，检查是否可以满足其需求
                for m in range(num_stations):
                    if remaining_demand[m] > 0:
                        demand_for_station = remaining_demand[m]  # 工作站 m 的剩余需求
                        weight_for_station = demand_for_station * weights[m, t]  # 根据工作站的需求和权重计算当前需求对应的总重量
                        # 配送的约束应该是不超过容量且不超过重量限制
                        if vehicle_capacity >= weight_for_station and vehicle_boxes + demand_for_station <= \
                                max_vehicle_counts[model_idx]:
                            vehicle_assignment.append((m, demand_for_station, weight_for_station))
                            remaining_demand[m] -= demand_for_station
                            vehicle_capacity -= weight_for_station
                            vehicle_boxes += demand_for_station

                if vehicle_assignment:
                    vehicles_for_period.append((current_vehicle_type, vehicle_assignment))
                    break

            if len(vehicle_assignment) == 0:
                # print(f"警告：周期 {t + 1} 未能分配任何物料，提前终止分配。")
                break

        vehicle_allocations.append(vehicles_for_period)

    return individual, inventory, vehicle_allocations

def objective( num_cycles, num_stations, inventory, distances, weights, vehicle_weights,vehicle_allocations,
        demand, initial_inventory, max_vehicle_loads, max_vehicle_counts, integer_layer):
    f1 = 0
    f2 = 0

    # 更新库存和计算库存目标
    for t in range(num_cycles-1):
        for m in range(num_stations):
            assert 0 <= t < num_cycles, f"周期索引 t={t} 超出范围"
            assert 0 <= m < num_stations, f"工作站索引 m={m} 超出范围"
            if t == 0:
                # 初始化库存
                inventory[m, t] = initial_inventory[m]
            else:
                inventory[m, t] = inventory[m, t - 1] + integer_layer[m, t] - demand[m, t]
            f1 += inventory[m, t]  # 计算总库存
    print(f1,"总库存值")

    # 遍历每个周期 t，确保 t 不会超出 vehicle_allocations 的范围
    for t in range(min(num_cycles, len(vehicle_allocations))):  # 使用 min 确保 t 不会越界
        if isinstance(vehicle_allocations[t], (list, tuple)):  # 确保是可迭代对象
            if vehicle_allocations[t]:  # 检查当前时间周期是否有车辆分配
                for vehicle in vehicle_allocations[t]:  # 遍历每个车型及其分配的车辆信息
                    vehicle_type, allocations = vehicle  # vehicle 是一个元组 ('车型', [(车辆ID, 负载, 其他信息), ...])
                    for allocation in allocations:  # 遍历每个车辆分配
                        vehicle_id, load, other_info = allocation  # 分解车辆信息
                        # 处理每辆车的分配，进行相关的适应度计算
                        pass  # 这里放置具体的适应度计算逻辑

    # 确保 t 的值不会超过 inventory 的列数
    for t in range(min(len(vehicle_allocations), num_cycles)):  # 使用 min 确保 t 不会越界
        if t < num_stations:  # 确保 t 不会超出库存的列数
            period_energy = 0
            remaining_inventory = inventory[:, t]  # 当前周期的库存

            if isinstance(vehicle_allocations[t], (list, tuple)):  # 确保是可迭代对象
                if vehicle_allocations[t]:  # 确保当前周期有车辆分配
                    for vehicle in vehicle_allocations[t]:  # 确保索引合法
                        vehicle_type, assignments = vehicle
                        vehicle_self_weight = vehicle_weights[int(vehicle_type[-1]) - 1]

                        # 仓库到第一个工作站
                        first_station, _, _ = assignments[0]
                        load_weight = sum(w for _, _, w in assignments)
                        period_energy += (load_weight + vehicle_self_weight) * distances['warehouse'][first_station]

                        # 工作站之间移动
                        for i in range(len(assignments) - 1):
                            current_station, _, _ = assignments[i]
                            next_station, _, _ = assignments[i + 1]
                            load_weight -= assignments[i][2]
                            period_energy += (load_weight + vehicle_self_weight) * distances['stations'][current_station][next_station]

                        # 返回仓库
                        last_station, _, _ = assignments[-1]
                        period_energy += vehicle_self_weight * distances['warehouse'][last_station]
            # 总能耗
            f2 += period_energy

        print(f"Total Inventory: {f1}, Total Energy: {f2}")


    return f1, f2



