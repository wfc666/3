import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
import math
import time
import sys
from scipy.io import savemat

from parameters import initialize_parameters
from initialize import Individual
from obj import objective
from Non_domination_sort import non_domination_sort
from Crowding import crowding_distance_sort
from Elitism import elitism
from OR import OR
from operators import MO1, MO2, MO3, CO1, CO2, CO3

start=time.time()#开始计时
state = 'train' #'test'

rate_LS1 = 0.2 #LS1局部优化比例
rate_LS2 = 0.6 #LS2局部优化比例
minf1 = []
minf2 = []

if __name__ == '__main__':
    # %%导入参数
    num_stations, num_cycles = 50, 50
    max_gen = 300
    # %%导入参数
    (num_cycles, num_stations, max_inventory, distances, weights, f_num, NP, max_gen, vehicle_weights,
     demand, initial_inventory, max_vehicle_loads, max_vehicle_counts) = initialize_parameters(max_gen=300)

    # %%初始化种群
    pop = []
    for i in range(NP):
        pop.append(Individual([], num_cycles, num_stations))

    # %%计算目标值和最大值
    for i in range(NP):
        pop[i].f = objective(pop[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                             vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,
                             f_num)

    # %%计算帕累托等级
    F, pop = non_domination_sort(NP, pop, f_num)

    # %% 计算拥挤度距离
    pop = crowding_distance_sort(F, pop, f_num)

    # %% 计算最小目标值
    x, y = [], []
    for i in range(len(pop)):
        if pop[i].paretorank == 1:
            x.append(pop[i].f[0])
            y.append(pop[i].f[1])
    minf1.append(min(x))
    minf2.append(min(y))

    # %% 计算OR
    OR_value = OR(pop)

    # %% 迭代循环
    for gen in range(max_gen):
        # %% 贪婪
        if random.random() <= 0.025:
            pop1 = []
            for i in range(len(pop)):
                pop1.append(MO1(pop[i].individual, num_cycles, num_stations))
            pop2 = []
            for i in range(len(pop)):
                pop2.append(MO2(pop[i].individual, num_cycles, num_stations))
            pop3 = []
            for i in range(len(pop)):
                pop3.append(MO2(pop[i].individual, num_cycles, num_stations))
            pop4 = []
            for i in range(len(pop)):
                pop4.append(CO1(pop[i].individual, num_cycles, num_stations))
            pop5 = []
            for i in range(len(pop)):
                pop5.append(CO2(pop[i].individual, num_cycles, num_stations))
            pop6 = []
            for i in range(len(pop)):
                pop6.append(CO3(pop[i].individual, num_cycles, num_stations))
            # pop7 = []
            # for i in range(len(pop)):
            #     if random.random() < rate_LS1:
            #         pop7.append(
            #             LS1(pop[i].individual, S, T, station_capacity, I0, material_demand, RP, max_station_capacity_A,
            #                 max_station_capacity_B, material_type))
            # pop8 = []
            # for i in range(len(pop)):
            #     if random.random() < rate_LS2:
            #         pop8.append(
            #             LS2(pop[i].individual, S, T, station_capacity, I0, material_demand, RP, max_station_capacity_A,
            #                 max_station_capacity_B, material_type))

            # 并计算目标值
            for i in range(len(pop1)):
                pop1[i].f = objective(pop[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                          vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,f_num)
            for i in range(len(pop2)):
                pop2[i].f = objective(pop2[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                          vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,f_num)
            for i in range(len(pop3)):
                pop3[i].f = objective(pop3[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                          vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,f_num)
            for i in range(len(pop4)):
                pop4[i].f = objective(pop4[i].individual,num_cycles, num_stations, max_inventory, distances, weights,
                          vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,f_num)
            for i in range(len(pop5)):
                pop5[i].f = objective(pop5[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                          vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,f_num)
            for i in range(len(pop6)):
                pop6[i].f = objective(pop6[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                          vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,f_num)
            for i in range(len(pop7)):
                pop7[i].f = objective(pop7[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                          vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,f_num)
            for i in range(len(pop8)):
                pop8[i].f = objective(pop8[i].individual, num_cycles, num_stations, max_inventory, distances, weights,
                          vehicle_weights, demand, initial_inventory, max_vehicle_loads, max_vehicle_counts,f_num)
            # 计算帕累托和拥挤度距离
            F, pop1 = non_domination_sort(len(pop1), pop1, f_num)
            pop1 = crowding_distance_sort(F, pop1, f_num)
            F, pop2 = non_domination_sort(len(pop2), pop2, f_num)
            pop2 = crowding_distance_sort(F, pop2, f_num)
            F, pop3 = non_domination_sort(len(pop3), pop3, f_num)
            pop3 = crowding_distance_sort(F, pop3, f_num)
            F, pop4 = non_domination_sort(len(pop4), pop4, f_num)
            pop4 = crowding_distance_sort(F, pop4, f_num)
            F, pop5 = non_domination_sort(len(pop5), pop5, f_num)
            pop5 = crowding_distance_sort(F, pop5, f_num)
            F, pop6 = non_domination_sort(len(pop6), pop6, f_num)
            pop6 = crowding_distance_sort(F, pop6, f_num)
            F, pop7 = non_domination_sort(len(pop7), pop7, f_num)
            pop7 = crowding_distance_sort(F, pop7, f_num)
            F, pop8 = non_domination_sort(len(pop8), pop8, f_num)
            pop8 = crowding_distance_sort(F, pop8, f_num)

            # 计算OR
            OR_matrix = []
            OR_matrix.append(OR(pop1))
            OR_matrix.append(OR(pop2))
            OR_matrix.append(OR(pop3))
            OR_matrix.append(OR(pop4))
            OR_matrix.append(OR(pop5))
            OR_matrix.append(OR(pop6))
            OR_matrix.append(OR(pop7))
            OR_matrix.append(OR(pop8))

            # 最优的算子
            max_idx = np.argmax(np.array(OR_matrix))
            pop_optimal = eval('pop' + str(max_idx + 1))
            # 合并种群
            pop_comb = pop + pop_optimal
            # 计算帕累托
            F, pop_comb = non_domination_sort(len(pop_comb), pop_comb, f_num)
            # 计算拥挤度距离
            pop_comb = crowding_distance_sort(F, pop_comb, f_num)
            # 选择前NP个个体
            pop = elitism(NP, pop_comb, f_num)

        # 随机
        else:
            operator_idx = np.random.choice(['MO1', 'MO2', 'MO3', 'CO1', 'CO2', 'CO3', 'LS1', 'LS2'])
            pop_offspring = []
            if operator_idx == 'MO1':
                for i in range(len(pop)):
                    pop_offspring.append(MO1(pop[i].individual, S, T, station_capacity))
            elif operator_idx == 'MO2':
                for i in range(len(pop)):
                    pop_offspring.append(MO2(pop[i].individual, S, T, station_capacity))
            elif operator_idx == 'MO3':
                for i in range(len(pop)):
                    pop_offspring.append(MO2(pop[i].individual, S, T, station_capacity))
            elif operator_idx == 'CO1':
                for i in range(len(pop)):
                    individual1 = pop[i].individual
                    individual2 = pop[random.randint(0, len(pop) - 1)].individual
                    pop_offspring.append(CO1(individual1, individual2, S, T, station_capacity))
            elif operator_idx == 'CO2':
                for i in range(len(pop)):
                    individual1 = pop[i].individual
                    individual2 = pop[random.randint(0, len(pop) - 1)].individual
                    pop_offspring.append(CO2(individual1, individual2, S, T, station_capacity))
            elif operator_idx == 'CO3':
                for i in range(len(pop)):
                    pop_offspring.append(CO3(pop[i].individual, S, T, station_capacity))
            # elif operator_idx == 'LS1':
            #     for i in range(len(pop)):
            #         if random.random() < rate_LS1:
            #             pop_offspring.append(LS1(pop[i].individual, S, T, station_capacity, I0, material_demand, RP,
            #                                      max_station_capacity_A, max_station_capacity_B, material_type))
            # elif operator_idx == 'LS2':
            #     for i in range(len(pop)):
            #         if random.random() < rate_LS2:
            #             pop_offspring.append(LS2(pop[i].individual, S, T, station_capacity, I0, material_demand, RP,
            #                                      max_station_capacity_A, max_station_capacity_B, material_type))



            # 计算目标值
            for i in range(len(pop_offspring)):
                pop_offspring[i].f = objective(pop_offspring[i].individual, T, S, CT, LT, UT, I0, material_demand,
                                               material_type, QAGV_A, QAGV_B, Qpart, vehicle_capacity, DS, DMS,
                                               velocity, f_num)
                # print(pop_offspring[i].f)
                # if pop_offspring[i].f[0] < 0:
                #    sys.exit(0)
            # 合并种群
            pop_comb = pop + pop_offspring
            # 计算帕累托
            F, pop_comb = non_domination_sort(len(pop_comb), pop_comb, f_num)
            # 计算拥挤度距离
            pop_comb = crowding_distance_sort(F, pop_comb, f_num)
            # 选择前NP个个体
            pop = elitism(NP, pop_comb, f_num)

        print(gen)
        x, y = [], []
        for i in range(len(pop)):
            if pop[i].paretorank == 1:
                x.append(pop[i].f[0])
                y.append(pop[i].f[1])
        minf1.append(min(x))
        minf2.append(min(y))

        if gen % 99 == 0:
            plt.scatter(x, y, marker='o', color='red', s=40)
            plt.xlabel('f1')
            plt.ylabel('f2')
            plt.show()
        stop = time.time()
        print(stop - start)
        # if stop - start > 300:
        #     break
    # %%
    savemat('./对比实验/对比1/rg_f1_5.mat', {'f1': minf1})
    savemat('./对比实验/对比1/rg_f2_5.mat', {'f2': minf2})
    x = np.array([x]).T
    y = np.array([y]).T
    xy = np.concatenate((x, y), axis=1)
    savemat('./对比实验/对比1/rg_pf_5.mat', {'pf': xy})

    end = time.time()
    print("循环时间：%2f秒" % (end - start))
    # import winsound
    # winsound.Beep(200,1000)

